/etc/init.d/pure-ftpd enable
/etc/init.d/lighttpd enable
ln -sf /etc/crontabs/root /etc/crontab
/etc/init.d/cond enable
reboot