/etc/init.d/pure-ftpd enable
/etc/init.d/lighttpd enable
reboot